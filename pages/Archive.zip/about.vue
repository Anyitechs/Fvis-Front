<template>
  <div>
    <Header />
    <div class="sub-header p-relative">
      <div class="overlay overlay-bg-black"></div>
      <div class="pattern"></div>
      <div class="section-padding">
        <div class="container">
          <div class="row">
            <div class="col-12">
              <div class="sub-header-content p-relative">
                <h1 class="text-light lh-default fw-600">About Us</h1>
                <ul class="custom">
                  <li>
                    <NuxtLink to="/" class="text-light">Home</NuxtLink>
                  </li>
                  <li class="text-light active">About Us</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <section class="section-padding about-us-sec p-relative">
      <div class="side-lines">
        <span class="box"></span>
        <span class="text">Fvis Ng</span>
        <span class="line"></span>
      </div>
      <div class="container">
        <div class="row">
          <div class="col-lg-6 align-self-center">
            <div class="about-left-side mb-md-40">
              <h3 class="text-custom-black fw-700">Who We Are?</h3>
              <p class="text-light-white fs-14 mb-xl-20">
                First Vibrant Integrated Services (FVIS) has excelled in Financial Management, Investments,
                and Consultancy for many years and now extends our successful tenure to provide talent development, corporate, and personal loans, as well as facilitating your charitable ventures.
              </p>
              <p
                class="text-light-white fs-14 mb-xl-20"
              >With five successful companies scattered across the globe in Malaysia, UAE, Singapore, Hong Kong, and our parent company in the USA, you can rest assured that FVIS INVESTMENT LTD will provide only the most exemplary service.</p>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="about-right-side-img p-relative">
              <div class="first-img p-relative">
                <img src="/assets/images/aboutus.jpg" class="img-fluid full-width" alt="about us" />
              </div>
            </div>
            <NuxtLink to="/membership">
              <button class="mt-4 btn-first btn-submit-fill btn-height full-width">BECOME A MEMBER</button>
            </NuxtLink>
          </div>
        </div>
      </div>
    </section>
    <section class="section-padding bg-gray our-articles">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="section-header mt-3">
              <div class="section-heading">
                <h3 class="text-custom-black fw-700">What We Offer</h3>
              </div>
            </div>
            <p
              class="text-light-white fs-14 mb-xl-20"
            >We offer a wide range of Proven Financial Investment solutions and support services to individuals, companies/large-scale organisation and small scale businesses including:</p>
            <ul>
              <li>Business Setup</li>
              <li>Project Financing</li>
              <li>Commodity Trading</li>
              <li>Property Management</li>
              <li>Workforce/Human Resources</li>
              <li>Financial Investment Solutions</li>
              <li>Real Estate Consulting And Development</li>
              <li>Oil and Gas services</li>
              <li>Supply Management Services</li>
            </ul>
            <p class="text-light-white fs-14 mb-xl-20">
              Take advantage of our personal loans and reach your financial goals now! Whether funding a home renovation, splurging on a holiday, or consolidating debt, our flexible options will provide the perfect solution.
              Our FVIS personal loan’s team is on call to analyze your individual circumstances and make the best recommendation for your specific needs. No need to wait to fulfil your dreams, let FVIS INVESTMENT LTD provide the perfect customized personal loan with a repayment plan that fits your budget.
            </p>
          </div>
        </div>
      </div>
    </section>
    <section class="section-padding our-articles">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="section-header mt-3">
              <div class="section-heading">
                <h3 class="text-custom-black fw-700">Organogram</h3>
              </div>
            </div>
            <p>FVIS Investment Organisational Chart</p>
            <div class="d-flex justify-content-center">
              <img src="assets/images/org.webp" class="full-width w-75" alt="Organogram" />
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="section-padding bg-gray our-articles">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="section-header mt-3">
              <div class="section-heading">
                <h3 class="text-custom-black fw-700">Management</h3>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-4">
                <div class="welcome-box mb-md-40">
                  <img
                    class="w-50"
                    src="assets/images/profiles/Amawhe.webp"
                    alt="Engr. Akbar Bin Amawhe"
                  />
                  <div class="welcome-text">
                    <h4 class="text-custom-black">Engr. Akbar Bin Amawhe</h4>
                    <strong class="text-custom-black">CEO/President</strong>
                  </div>
                </div>
              </div>
            </div>
            <p
              class="text-light-white fs-14 mb-xl-20"
            >Engr. Akbar Bin Amawhe co-founded FVIS LLC USA He’s currently the CEO/President of FVIS Investment LTD, (Nigeria), FVIS SDN BHD (Malaysia), FVIS PTE LTD (Singapore) and FVIS Far East LTD (Hong Kong). He further co-founded AT Network Sdn Bhd and oversees the finance and quality of deal flow at Beyond Network.</p>
            <p
              class="text-light-white fs-14 mb-xl-20"
            >His expertise as an early Startup Accelerator has been vital to Beyond Network’s success, as can be witnessed in the many other companies he co-founded. With his PhD in Electrical, Electronics, and Communication Engineering, Engr. Amawhe is equipped with both the technical skills, as well as the hands-on expertise necessary to drive FVIS Nigeria forward.</p>
            <p
              class="text-light-white fs-14 mb-xl-20"
            >In the role of Chief Executive Officer, he possesses experience in the Aviation/Aeronautic Engineering Industry, as well as the oil & energy industry. He further boasts experience in Project Finance, Real Estate and Affordable Housing Investment Program, Business Planning/ Business Development, and Risk Management, and more, as well as top negotiation skills.</p>
            <p
              class="text-light-white fs-14 mb-xl-20"
            >Engr. Amawhe is proud to be part of FVIS Nigeria’s experienced top management team and more importantly, he believes in giving back to the next wave of upcoming entrepreneurs, as well as the general public.</p>
            <div class="row">
              <div class="col-md-4">
                <div class="card" style="width: 18rem;">
                  <img src="/assets/images/platinum.png" class="card-img-top" />
                  <div class="card-body">
                    <p class="card-text">The Rich-List Club International.</p>
                  </div>
                </div>
              </div>
              <div class="col-md-4 mr-auto">
                <div class="card" style="width: 18rem;">
                  <img src="/assets/images/alliance.png" class="card-img-top" />
                  <div class="card-body">
                    <p class="card-text">The Humanity Alliance.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="section-padding our-articles">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="row">
              <div class="col-lg-4">
                <div class="welcome-box mb-md-40">
                  <img
                    class="w-50"
                    src="assets/images/profiles/Haissam.webp"
                    alt="Haissam El Chami"
                  />
                  <div class="welcome-text">
                    <h4 class="text-custom-black">Haissam El Chami</h4>
                    <strong class="text-custom-black">Managing Director</strong>
                  </div>
                </div>
              </div>
            </div>
            <p
              class="text-light-white fs-14 mb-xl-20"
            >Haissam El Chami brings over 20 years’ experience to FVIS Nigeria with marketing and sales roles spanning across various industries.</p>
            <p
              class="text-light-white fs-14 mb-xl-20"
            >Haissam graduated in Business Administration &amp; Management from the University Of New York, where-after he worked in the hospitality field between Lebanon, Saudi Arabia &amp; Dubai from 1983 till 1991.</p>
            <p
              class="text-light-white fs-14 mb-xl-20"
            >During 1991 he decided to make a huge shift in his career and moved to Media, Advertising &amp; Marketing to join one of the largest Lebanese Media company’s, RLP, from 1991 till 1994.</p>
            <p
              class="text-light-white fs-14 mb-xl-20"
            >After his successful tenure at RLP, Hassaim moved to Jeddah in Saudi Arabia and joined Al Khaleekiyah (the largest media group in KSA) in a Sales &amp; Marketing position.</p>
            <p
              class="text-light-white fs-14 mb-xl-20"
            >During 1997 he was appointed as media director for Team Young &amp; Rubicam (part of WPP worldwide) till 2000, where-after he joined AL Watan Newspaper, a Saudi local newspaper as their Sales &amp; Marketing Director.</p>
            <p
              class="text-light-white fs-14 mb-xl-20"
            >In 2002 he was appointed as managing director of MediaEdge, a Media Buying company part of the WPP worldwide Group until 2003, where-after he moved to Dubai as Regional Director of BrandConnection MENA, part of IPG worldwide group.</p>
            <p
              class="text-light-white fs-14 mb-xl-20"
            >During 2005, Haissam started his own media company in Dubai with branches in Jeddah, Riyadh, and Beirut, where-after he joined Beyond Network in Kuala Lumpur in November 2019.</p>
          </div>
        </div>
      </div>
    </section>
    <section class="section-padding bg-gray our-articles">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="row">
              <div class="col-lg-4">
                <div class="welcome-box mb-md-40">
                  <img
                    class="w-50"
                    src="assets/images/profiles/Joshua.webp"
                    alt="Mr. Joshua Amawhe"
                  />
                  <div class="welcome-text">
                    <h4 class="text-custom-black">Mr. Joshua Amawhe</h4>
                    <strong class="text-custom-black">Chief Financial Officer</strong>
                  </div>
                </div>
              </div>
            </div>
            <p class="text-light-white fs-14 mb-xl-20">
              Mr. Amawhe exhibits a true team player spirit, an integral part of any successful business.
              He boasts an exemplary track record with a relentless commitment to customer service, as well as a strong background in both general administration and accounting.
            </p>
            <p
              class="text-light-white fs-14 mb-xl-20"
            >Since the start of his career in 2009, he’s earned various certifications and diplomas that finally brought him to his current position as CFO.</p>
          </div>
        </div>
      </div>
    </section>
    <section class="section-padding our-articles">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="row">
              <div class="col-lg-4">
                <div class="welcome-box mb-md-40">
                  <img
                    class="w-50"
                    src="assets/images/profiles/Johnson.webp"
                    alt="Evg. (Dr.) Johnson O."
                  />
                  <div class="welcome-text">
                    <h4 class="text-custom-black">Evg. (Dr.) Johnson O.</h4>
                    <strong class="text-custom-black">Chief Operating Officer</strong>
                  </div>
                </div>
              </div>
            </div>
            <p
              class="text-light-white fs-14 mb-xl-20"
            >With over 20 years’ experience, Evg. (Dr.) Johnson O. has taken the responsibility of implementing operational strategies, communicating policy to the staff, ensuring that corporate goals are attained while managing human resources.</p>
            <p class="text-light-white fs-14 mb-xl-20">
              In 2010 he took the role of President and International Coordinator for the Christian Network International Inc.
              In 2014 he completed his Doctorate Degree in Christian Leadership (Hons.) at the International School of Ministry in the USA.
            </p>
            <p
              class="text-light-white fs-14 mb-xl-20"
            >Later experience in his career he held the responsibility as Marketing Manager and Analyst for several Enterprise Organisations.</p>
            <p
              class="text-light-white fs-14 mb-xl-20"
            >Evg. (Dr.) Johnson O. has a strong focus on human resource development due to his extensive education in Christian Leadership, Human Resources, and Management Practices.</p>
            <h5>Memberships:</h5>
            <ul>
              <li>Young African Leaders Initiative (Yali) (Nigeria Chapter)</li>
              <li>Pastors &amp; Ministers Prayer Network for Africa (Obanikoro, Lagos)</li>
              <li>Pentecostal Fellowship of Nigeria (Ikeja, Lagos)</li>
              <li>The Apostolic Restoration Church of America (Elizabethtown, Kentucky, USA)</li>
              <li>Universal Life Church Monastery (Sacramento, California, USA)</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
    <section class="section-padding bg-gray our-articles">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="row">
              <div class="col-lg-4">
                <div class="welcome-box mb-md-40">
                  <img class="w-50" src="assets/images/profiles/Pius.webp" alt="Engr. John Pius" />
                  <div class="welcome-text">
                    <h4 class="text-custom-black">Engr. John Pius</h4>
                    <strong class="text-custom-black">Project Director</strong>
                  </div>
                </div>
              </div>
            </div>
            <p
              class="text-light-white fs-14 mb-xl-20"
            >With a career that grew from Technical Engineering, Engr. John Pius brings 24 years of Enterprise Project and Organisational Management experience to FVIS Nigeria. In 1994, after completing several Technical Engineering Diplomas, he began his career as a Technical Manager with Telecomtornic Nig. Ltd.</p>
            <p
              class="text-light-white fs-14 mb-xl-20"
            >As he climbed the corporate ladder, Engr. John Pius joined Integrated System Ltd in 1996 as a national Project Manager, where he focussed on the growth of their Electronic Cards and online transactions.</p>
            <p
              class="text-light-white fs-14 mb-xl-20"
            >With a keen determination to deliver on set targets and deliverables, he grew his responsibilities to eventually coordinate and manage a network of branches for leading banking and oil companies.</p>
            <p
              class="text-light-white fs-14 mb-xl-20"
            >In 1998 he was promoted to Managing Director for Telsec Technologies Ltd. where his responsibilities included Branch Network Expansion, Operating Cost Management, Staff Management, and Development.</p>
          </div>
        </div>
      </div>
    </section>
    <section class="section-padding our-articles">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="row">
              <div class="col-lg-4">
                <div class="welcome-box mb-md-40">
                  <img
                    class="w-50"
                    src="assets/images/profiles/Godwin.webp"
                    alt="Engr. Godwin Igie"
                  />
                  <div class="welcome-text">
                    <h4 class="text-custom-black">Engr. Godwin Igie</h4>
                    <strong class="text-custom-black">Oil &amp; Gas Manager</strong>
                  </div>
                </div>
              </div>
            </div>
            <p class="text-light-white fs-14 mb-xl-20">
              Engr. Godwin Igie is FVIS Nigeria’s expert consultant in the Petroleum
              Engineering and Geosciences field.
            </p>
            <p class="text-light-white fs-14 mb-xl-20">
              He has accumulated several professional qualifications ranging from
              Petroleum Engineering, Petroleum Production, Refinery and Petrochemical Operations, Industrial Safety to Reservoir Engineering in Oil and Gas Production.
            </p>
            <p class="text-light-white fs-14 mb-xl-20">
              As a consultant since 2008 at the Nigeria Petroleum Development
              Company (NPDC), his responsibilities extended across Crude Oil Production and Operations, Well Completion, Reservoir Engineering Management, and Fishing Operations.
            </p>
            <p
              class="text-light-white fs-14 mb-xl-20"
            >In 2010 he consulted with ExxonMobil as one of their highly profiled production technologist.</p>
            <p
              class="text-light-white fs-14 mb-xl-20"
            >Soon thereafter he consulted with the PTI Demonstration Rig facility for their technical training on Drilling Rig Operations, in 2011. Over the course of the following 4 years, he continued to assist the PTI Demonstration Rig facilities in talent development and training.</p>
            <p
              class="text-light-white fs-14 mb-xl-20"
            >In 2014, Engr. Godwin Igie consulted with the Ecomarine Terminal Calabar-free Port in Petroleum vessel discharge management and materials procurement services.</p>
            <p
              class="text-light-white fs-14 mb-xl-20"
            >With extensive experience in crude oil manufacture and plant management, Engr. Godwin Igie has indebt knowledge in both the upstream and downstream sector of the oil and Gas industry, in both deep offshore, shallow waters and onshore operations, He is a certified trainer in Petroleum production Technology, Engr Godwin makes the perfect consultant for FVIS Nigeria.</p>
            <h5>Memberships:</h5>
            <ul>
              <li>Member, Society of Petroleum Engineers.</li>
              <li>Member, Nigeria Association of Petroleum Exploration (NAPE)</li>
              <li>Member Nigeria institute of safety Professionals.</li>
              <li>Member American Association of Petroleum Geologist.</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
    <section class="section-padding bg-gray our-articles">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="row">
              <div class="col-lg-4">
                <div class="welcome-box mb-md-40">
                  <img class="w-50" src="assets/images/profiles/David.webp" alt="Engr. David Felix" />
                  <div class="welcome-text">
                    <h4 class="text-custom-black">Engr. David Felix</h4>
                    <strong class="text-custom-black">Administrative IT</strong>
                  </div>
                </div>
              </div>
            </div>
            <p
              class="text-light-white fs-14 mb-xl-20"
            >Engr. David Felix holds a B.Sc in Computer Science and has amassed several professional qualifications including Network Management, Radio Frequency Engineering and Transmission Engineering as well as leadership development and management courses. He boasts 20 years’ experience in the ICT industry with experience ranging from Computer Analyst and Database Manager for Intercessors for Nigeria; Congress Administrator with PMPN Africa, where he supported the International Congress Committee with administration and registration data input from over 20 nations.</p>
            <p
              class="text-light-white fs-14 mb-xl-20"
            >He also served as the ICT Manager & Database Administrator, where his responsibilities included the management, installation, maintenance and security of the network including hardware and software systems. He has severally travelled to South Africa, Zambia and Uganda managing the ICT, Administration and Training facilities and staff of the organisation.</p>
            <p
              class="text-light-white fs-14 mb-xl-20"
            >He served in PMPN, Africa Missions Partners Fund (AMPF) and PMTI as the Head of Administration and Communication, overseeing operations across Africa. His role included developing operational guidelines and policies, managing administrative budgets and maintaining corporate relationships with partner organizations. Managing all part of the IT department, including supervision, hiring certain members and handling employees concerns and performances and developing e-learning platforms.</p>
            <p
              class="text-light-white fs-14 mb-xl-20"
            >He is a seasoned and committed professional with comprehensive business and technical skill set, project management, leadership, software planning and development, web application development, customer service and team Management.</p>
            <h5>Leader/Member of:</h5>
            <ul>
              <li>Pastors/Ministers Prayer Network Africa</li>
              <li>Alumnus of Pastors/Ministers Training Institute</li>
              <li>Alumni, TTC</li>
              <li>Club 1840</li>
              <li>YALI (Nigeria)</li>
              <li>NYC, RCCG YAYA</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
    <section class="section-padding our-articles">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="row">
              <div class="col-lg-4">
                <div class="welcome-box mb-md-40">
                  <img
                    class="w-50"
                    src="assets/images/profiles/Olawale.webp"
                    alt="Ayorinde Oluseyi Olawale"
                  />
                  <div class="welcome-text">
                    <h4 class="text-custom-black">Ayorinde Oluseyi Olawale</h4>
                    <strong class="text-custom-black">Real Estate Manager</strong>
                  </div>
                </div>
              </div>
            </div>
            <p
              class="text-light-white fs-14 mb-xl-20"
            >Ayorinde Oluseyi Olawale is a seasoned professional with specialized expertise in Land Surveying, Geomantic Engineering, and Applied Geoinformatics (GIS applications).</p>
            <p
              class="text-light-white fs-14 mb-xl-20"
            >With almost 20 years’ experience in Property and Land Development, Mr. Olawale is the perfect Property Consultant with knowledge of Data Processing for building projects which include Soil Composition and Volumetric Computation, Structural Plan Evaluations, Engineering Surveys, and Hydrographic Surveys.</p>
            <p
              class="text-light-white fs-14 mb-xl-20"
            >After completing his professional education in 2011, he started his consulting career with Abiye Surveys &amp; Resources in 2012 whereby he gained vast knowledge in surveying equipment for Smart Total Forecourt Stations using laser scanners, GPS and DGPS (RTK) equipment.</p>
            <p
              class="text-light-white fs-14 mb-xl-20"
            >Mr. Olawale’s software and operational skills extend across Architectural, Land and Property Surveying programs such as AutoCAD, Carlsson, LandDEV, ArcGIS, ENVI, ILWIS amongst several others. Further consulting projects include the work conducted for Dominion Onward Real Estate and Properties in 2017 and Jomtob Real Estate &amp; Properties in 2019.</p>
            <p
              class="text-light-white fs-14 mb-xl-20"
            >His advisory services included Project Construction Progress Surveying, Company Policy Formulation, Drainage Plan Development with Foreman and Supervisor assistance.</p>
            <h5>Memberships:</h5>
            <ul>
              <li>Surveyors Council of Nigeria (SURCON)</li>
              <li>Nigeria Institution of surveyor (NIS)</li>
              <li>Young Surveyors Network (YSN)</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
    <section class="section-padding bg-gray our-articles">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="section-header mt-3">
              <div class="section-heading">
                <h3 class="text-custom-black fw-700">Customer Philosophy</h3>
              </div>
            </div>
            <blockquote class="mb-xl-20">
              <p class="text-custom-black fw-600">
                "Our success is based on the success of our customers.
                Thus our business model is based on focusing on our customers’ needs and tending to these needs most efficiently and profitably."
              </p>
            </blockquote>
          </div>
        </div>
      </div>
    </section>
    <section class="section-padding our-articles">
      <div class="container">
        <div class="row">
          <article class="col-lg-4 col-md-6 post mb-xl-30">
            <div class="post-wrapper">
              <div class="blog-meta padding-20">
                <div class="post-content">
                  <h2>
                    <span class="text-custom-black fw-600">Our Mission</span>
                  </h2>
                  <p
                    class="text-light-white"
                  >Our mission is to provide an array of services that support mutually beneficial projects and procedures between Employers and Employees that sustain the long- term prosperity of the company.</p>
                </div>
              </div>
            </div>
          </article>
          <article class="col-lg-4 col-md-6 post mb-xl-30">
            <div class="post-wrapper">
              <div class="blog-meta padding-20">
                <div class="post-content">
                  <h2>
                    <span class="text-custom-black fw-600">Our Vision</span>
                  </h2>
                  <p
                    class="text-light-white"
                  >By instilling the values of FVIS in every corner of the world, we aim to ultimately eradicate unemployment globally through the services we offer to employees and employers.</p>
                </div>
              </div>
            </div>
          </article>
          <article class="col-lg-4 col-md-6 post mb-xl-30">
            <div class="post-wrapper">
              <div class="blog-meta padding-20">
                <div class="post-content">
                  <h2>
                    <span class="text-custom-black fw-600">Core Values</span>
                  </h2>
                  <p
                    class="text-light-white"
                  >Our core values are the pillars of our success. We measure all our endeavours against three simple values: Honesty, Integrity, and Transparency. These values provide both FVIS and all our clients the exact tools needed to ensure rapid, yet sustainable growth.</p>
                </div>
              </div>
            </div>
          </article>
        </div>
      </div>
    </section>

    <Footer />
  </div>
</template>

<script>
import Header from '~/components/frontend/Header'
import Footer from '~/components/frontend/Footer'
export default {
  components: {
    Header,
    Footer
  },
  data() {
    return {
      org: '',
      ovm: '',
      wwo: 'active',
      wwopanel: 'active show',
      ovmpanel: '',
      orgpanel: ''
    }
  },
  head() {
    return {
      title: 'About Us - Fvis Nig',
      meta: [
        {
          hid: 'description',
          name: 'description',
          content:
            'FVIS Nigeria has excelled in Financial Management, Investments, and Consultancy for many years and now extends our successful tenure to provide talent development, corporate, and personal loans, as well as facilitating your charitable ventures.'
        }
      ]
    }
  },
  methods: {
    openovm() {
      this.ovmpanel = 'active show'
      this.ovm = 'active'
      this.orgpanel = this.wwopanel = this.org = this.wwo = ''
    },
    openwwo() {
      this.wwopanel = 'active show'
      this.wwo = 'active'
      this.orgpanel = this.ovmpanel = this.org = this.ovm = ''
    },
    openorg() {
      this.orgpanel = 'active show'
      this.org = 'active'
      this.ovmpanel = this.wwopanel = this.ovm = this.wwo = ''
    }
  },
  beforeMount() {
    this.$store.commit('frontmenu/RESET_MENU_TOGGLE')
  }
}
</script>

<style scoped>
.about-us-sec .about-right-side-img:after {
  content: '';
  position: absolute;
  top: 100px;
  left: 20px;
  right: 100px;
  height: calc(100% - 120px);
  background: #ffffff85;
  z-index: 1;
}
</style>
