<template>
  <div>
    <Header/>
    <div class="sub-header p-relative">
      <div class="overlay overlay-bg-black"></div>
      <div class="pattern"></div>
      <div class="section-padding">
        <div class="container">
          <div class="row">
            <div class="col-12">
              <div class="sub-header-content p-relative">
                <h1 class="text-custom-white lh-default fw-600">Services</h1>
                <ul class="custom">
                  <li>
                    <NuxtLink to="/" class="text-custom-white">Home</NuxtLink>
                  </li>
                  <li class="text-custom-white active">Services</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>


    <section class="section-padding bg-gray">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="blog-detail padding-20">
              <!-- article -->
              <article class="post">
                <div class="post-wrapper">
                  <div class="blog-meta">
                    <h3 class="text-custom-black fw-600 my-4">Services</h3>
                    <div class="row">
                      <div class="col col-md-6">
                        <p class="text-light-white">
                          <strong>Real Estate:</strong> Rely on our expert management services to provide superior
                          quality investment opportunities, ideally suited to your specific business needs.
                        </p>
                        <p class="text-light-white">
                          <strong>Project Financing:</strong> Our consultants develop sustainable, flexible, and
                          uniquely structured project financing solutions that meet your exact needs.
                        </p>
                        <p class="text-light-white">
                          <strong>Loan Facilities:</strong> We open up a world of loan facilities to satisfy your
                          specific requirements.
                          Whether you need committed facilities, retail credit accounts, revolving credit, term loans,
                          or letters of credit, FVIS INVESTMENT LTD provides it all.
                        </p>
                        <p class="text-light-white">
                          <strong>Oil and Gas:</strong> By building a structure that offers reliability, efficiency and
                          optimum productivity, we provide practical solutions to any challenges in the Oil and Gas
                          industry.
                        </p>
                        <p class="text-light-white">
                          <strong>Corporate Financing:</strong> Our comprehensive offering covers a myriad of options to
                          make sure your business receives precisely what it needs to thrive. Whether crowdfunding,
                          microloans, vendor financing, or purchase order financing, our team will pinpoint the perfect
                          solution for you.
                        </p>
                      </div>
                      <div class="col col-md-6">
                        <p class="text-light-white">
                          <strong>Personal Loans:</strong> Take advantage of our personal loans and reach your financial
                          goals now! Whether funding a home renovation, splurging on a holiday, or consolidating debt,
                          our flexible options will provide the perfect solution.
                        </p>
                        <p class="text-light-white">
                          <strong>Talent development:</strong> Keep your business three steps ahead with our bespoke
                          talent development programs. By providing your organization with new skills and learning
                          opportunities, you increase overall efficiency that stimulates company growth to maintain your
                          competitive advantage.
                        </p>
                        <p class="text-light-white">
                          <strong>Fixed income investments:</strong> Each business requires access to a unique
                          combination of high-yielding fixed income investments to maintain a successful portfolio. FVIS
                          INVESTMENT LTD provides access to treasury bonds, agency, and government bonds, corporate
                          bonds, municipal bonds, mortgage-backed securities, and more!
                        </p>
                        <p class="text-light-white">
                          <strong>Charity:</strong> Let FVIS INVESTMENT LTD facilitate your charitable ventures by
                          streamlining access to the world’s best NGOs. We help you help the world by assisting in
                          raising funds, as well as the fair disbursement of all monies.
                        </p>
                      </div>
                    </div>
                    <h5 class="text-custom-black fw-600">Project Financing</h5>
                    <p class="text-light-white">
                      Because, although the world is rife with a host of lucrative opportunities for bold
                      entrepreneurs, the funding to support these incredible visions can be hard to obtain. FVIS
                      INVESTMENT LTD refuses to allow inadequate funding to stop entrepreneurs from realizing the
                      potential of their dreams, especially large scale projects that promise positive transformational
                      effects on both the local and global economy.
                      <br/>By combining our in-depth industry knowledge, financial expertise and risk management
                      experience, we make sure that both developers and communities benefit from investment in critical
                      infrastructure projects.
                      <br/>There is no substitute for top expertise to tackle the challenges of international project
                      development. FVIS Nigeria appreciates the critical role that properly structured financing plays
                      in the success of every project, well before the actual construction starts, and long into the
                      first years of operations.
                      <br/>Our expert team provides the structure for your specific project requires to excel in every
                      phase of development, to ensure you meet both your short- and long-term financial goals while
                      achieving a handsome return on investment to continue driving the growth of all your other
                      initiatives forward.
                      <br/>No matter the requirements of your project, our collective and extensive global investment
                      experience, coupled with in-depth industry knowledge, is the key to providing your next venture
                      with the solid foundation it deserves.
                      <br/>Approach FVIS INVESTMENT LTD and enjoy unsurpassed professionalism from a company that is
                      perfectly equipped to bring your visions to life – globally.
                    </p>
                    <h5 class="text-custom-black fw-600 my-4">Real Estate</h5>
                    <p class="text-light-white">
                      Because we consider you and your business’ goals to develop a solution that perfectly suits your
                      demands, you can rely on our expert management services to provide bespoke, superior quality
                      investment opportunities – no matter your requirements.
                      <br/>Our comprehensive service offering covers the entire spectrum of real estate investment to
                      include site evaluations and selections, planning, as well as the execution of strategies:
                      acquisition, disposition, re-entitlement, planning, and development, as well as the actual funding
                      of your project and managing the property after development is concluded.
                      <br/>Whether your real estate development project is big or small, our expert consultants treat
                      every client with the same respect and apply the same sense of urgency to all aspects of every,
                      single project.
                      <br/>And while in general, property development is a long term investment that only generates
                      returns after an extended period, entrusting FVIS with your entire project promises quicker
                      returns at a much earlier stage than industry standards.
                      <br/>Executing a successful development project and managing an entire property portfolio requires
                      specific expertise and dedication. FVIS INVESTMENT LTD takes care of every last detail while
                      keeping you updated every step of the way. By partnering with us, you minimize your overall risk
                      to reach your business goals faster.
                      <br/>Join forces with FVIS INVESTMENT LTD and gain access to a compendium of experts in their
                      respective fields: Investors, contractors, engineers, banks, lenders, financial experts, and other
                      professional individuals. These professionals have all joined forces with us to the greater
                      benefit of all FVIS members.
                    </p>
                    <h5 class="text-custom-black fw-600 my-4">Fixed Income Investment</h5>
                    <p class="text-light-white">
                      Fixed income plays an integral role in any investor’s portfolio, but it is imperative to entrust
                      only the top industry players with your hard-earned money.
                      <br/>Whether your goal is to preserve principal, save for the future, diversify your investments,
                      or receive dependable income, fixed-income investments are vital in realizing your portfolio’s
                      potential and reach your financial goals.
                      <br/>FVIS INVESTMENT LTD appreciates that many clients are risk-averse, which is why we developed
                      an investment opportunity that delivers predictable income while maintaining an acceptable level
                      of risk. We make this incredible opportunity possible by investing in reliable long term
                      opportunities that promise high yields and a fast return on investment.
                      <br/>We also understand that every client’s budget vastly differs from the next. Hence we offer a
                      range of fixed investment plans. But no matter your budget and preferred plan, all our clients
                      enjoy our diligent service, prompt payments, and excellent service from our dedicated and
                      professional investment team.
                      <br/>Our highly skilled consultants are experts in servicing client portfolios, and knowledgeable
                      about the intensive research and due diligence that’s imperative to a lucrative fixed investment
                      portfolio. Through streamlined processes, we ensure both the safety and the liquidity of each
                      investment to provide the most attractive returns possible.
                      <br/>FVIS INVESTMENT LTD is committed to providing every client with personalized service to
                      ensure
                      we meet your particular financial needs. Our fixed-income investment strategies emphasize both
                      long-term growth as well as immediate returns by continually monitoring the direction interest
                      rates may be headed.
                      Our offering to our clients is a unique proposition with the perfect blend between industry
                      expertise and unrivalled customer service, which achieves exemplary results – every time
                    </p>
                    <h5 class="text-custom-black fw-600 my-4">Commodity Trading</h5>
                    <p class="text-light-white">
                      Oil and gas are two of the most significant exports and sources of foreign exchange for the
                      economy. And in the last couple of years, incredible opportunities presented themselves due to the
                      increasing demand for industrial gas, plus the rising demand for gas injection requirements used
                      to enhance oil and condensate the recovery from producing areas.
                      <br/>But although these commodities provide unprecedented returns, most clients veer away from
                      these opportunities that pose a higher investment risk. When partnering with a reputable firm like
                      FVIS INVESTMENT LTD, the inherent volatility and complexity of commodity trading fade away.
                      <br/>FVIS INVESTMENT LTD offers efficient, premium-quality commodity trading services at an
                      affordable rate, with our expert team wade through the myriad of trading options to hand-pick
                      trading options that provide you with the most lucrative solutions for your individual situation.
                      <br/>By combining our established strengths with the focus and culture expected from an
                      independent company, we unlock hidden potential that drives profits for our stakeholders while
                      also assisting in meeting global energy needs. Only by having access to an incredibly dedicated
                      and expert team of employees and partners are we able to embrace every opportunity to exceed our
                      customers’ needs.
                      <br/>A thorough investment plan, centered around the commodity market, benefits your investment
                      portfolio by improving your risk-adjusted profits, providing a stable investment platform that
                      remains unaffected by inflation, and offering much higher return rates when compared to other
                      asset classes.
                    </p>
                    <h5 class="text-custom-black fw-600 my-4">Coperate Financing</h5>
                    <p class="text-light-white">
                      Our comprehensive offering covers a myriad of options to make sure your business receives
                      precisely what it needs to thrive. Whether crowdfunding, microloans, vendor financing, or purchase
                      order financing, our team will pinpoint the perfect solution for you.
                      <br/>FVIS INVESTMENT LTD offers full-service corporate financing solutions to meet any size
                      company’s needs. With over 30 years of financial transaction and management experience across a
                      spectrum of industries, we focus on providing top-class strategic advisory services in the areas
                      of acquisitions, fund-raising, and divestitures.
                      <br/>Our highly-skilled team of experts is deeply involved in every aspect of your requirements to
                      provide only the best in industry service.
                      <br/>At FVIS INVESTMENT LTD, we appreciate that no two deals are the ever same. And while you are
                      an expert in running your business, the sale or acquisition of a business is a complex process
                      that is best handled with only the best financial professionals at your side.
                      <br/>Our corporate finance team has closed many successful transactions with our powerful
                      combination of corporate deal experience, entwined with relentless creativity and tenacity.
                      <br/>By carefully considering the needs of the owners, business and industry parameters, our team
                      arrives at the most suitable solution at any given time.
                      <br/>Trust FVIS INVESTMENT LTD to take care of every aspect of your corporate financing needs
                      swiftly and professionally.
                    </p>
                    <h5 class="text-custom-black fw-600 my-4">Personal Loans</h5>
                    <p class="text-light-white">
                      Take advantage of our personal loans and reach your financial goals now! Whether funding a home
                      renovation, splurging on a holiday, or consolidating debt, our flexible options will provide the
                      perfect solution.
                      <br/>Our FVIS personal loan’s team is on call to analyze your individual circumstances and make
                      the best recommendation for your specific needs.
                      <br/>No need to wait to fulfil your dreams, let FVIS INVESTMENT LTD provide the perfect customized
                      personal loan with a repayment plan that fits your budget.
                    </p>
                    <h5 class="text-custom-black fw-600 my-4">Loan Facilities</h5>
                    <p class="text-light-white">
                      FVIS opens up a world of loan facilities to satisfy your specific requirements. Whether you need
                      committed facilities, retail credit accounts, revolving credit, term loans, or letters of credit,
                      FVIS Nigeria provides it all.
                      <br/>Our vast experience in managing loans & credit markets ensures we provide premium-quality
                      service while dealing with all the complexities of such markets on your behalf.
                      <br/>To ensure you receive the perfect solution for your individual situation, you need an
                      experienced and competent agent to not only manage your cash flow and hold collateral but to
                      facilitate all communications with lenders to perform the necessary services required for these
                      types of transactions.
                      <br/>FVIS INVESTMENT LTD maximizes the comfort level on both sides of the transaction, which is
                      critical in ensuring lasting relationships that lead to successful loans. Many lenders prefer not
                      to deal directly with the customer, and to control costs, streamline administration and maximize
                      efficiency, they prefer working with a provider like FVIS INVESTMENT LTD that possesses the
                      necessary resources and infrastructure, plus a thorough understanding of their business
                      requirements.
                      The unrivalled experience of our excellent staff, combined with our flexible approach, ensures a
                      streamlined and tailor-made service to our clients. With a wealth of experience and in-depth
                      knowledge of the loans marketFVIS INVESTMENT LTD proves the most effective intermediary to
                      coordinate your best loan options.
                      Each deal with us is assigned a specific client services manager that takes full responsibility in
                      providing you with the highest level of client service.
                    </p>
                    <h5 class="text-custom-black fw-600 my-4">Talent Development</h5>
                    <p class="text-light-white">
                      New Talent Discovery
                      FVIS Nigeria constantly searches for new talent across all industries to first develop their
                      unique ideas or talents, and then find the perfect job opportunity or partnership that matches
                      their skills. Whether the music industry, technology field or the arts, our team are experts at
                      locating and curating top talent.
                      <br/>Employee Training
                      A multitude of surveys has proven the importance of individual development over an increase in
                      salary. And a company that provides ongoing professional development to their employees not only
                      enhance their overall effectiveness but builds a strong leadership pipeline for the immediate
                      future success of their company.
                      <br/>Employees that build their capabilities and skillsets see themselves as advancing in the
                      company in their individual career paths. A fully developed workforce helps your company to be
                      more competitive while your employees become increasingly engaged, more productive and loyal.
                      <br/>FVIS INVESTMENT LTD is a recognized leader in rolling out successful talent development
                      programs. By performing an initial assessment to ascertain the current condition of your teams, we
                      identify opportunities that will exponentially improve employee engagement and retention.
                      <br/>To fulfil our ongoing commitment in providing your company with a solid return on investment,
                      we implement customized, measurable solutions that build your employees’ talent in direct
                      correlation to your companies growth requirements.
                      <br/>The key to development is to gain more in-depth insight into every employee’s current
                      capability, pinpoint their gaps and then provide meaningful development activities to address
                      shortcomings. FVIS INVESTMENT LTD selects training modules from our extensive library of
                      self-insight and proven assessments that gives each participant a powerful development experience.
                      <br/>Our coaching methodology is based on building lasting relationships, driven by assessment and
                      measured based on the outcome. We combine an objective process-oriented approach to effect
                      behavior transformation with the experience that can only come from years of leadership coaching.
                      <br/>Contact FVIS now and leverage our extensive content and training library to start providing
                      your teams and company with unique solutions.
                    </p>
                    <h5 class="text-custom-black fw-600 my-4">Charity</h5>
                    <p class="text-light-white">
                      Corporate Social Responsibility (CSR) is an essential component of your business, but over and
                      above your regular business practices, it could become a cumbersome task.
                      <br/>Making monetary donations to various deserving causes is the most popular form of CSR, and
                      most companies pledge to donate a percentage of their earnings each year to charitable causes.
                      <br/>FVIS INVESTMENT LTD brings businesses and nonprofit organizations (NGOs) together to solve
                      the most pressing social challenges while facilitating all the administrative processes.
                      <br/>We believe in the value of NGOs and want to assist your organization in reaching beyond
                      conventional approaches and access assistance to achieve a more significant impact.
                      <br/>Your business might also receive requests for donations every day, but managing all those
                      requests is not only overwhelming but time-consuming. FVIS INVESTMENT LTD streamlines all of your
                      donation processes so that you can easily manage your CSR.
                      <br/>Our mission is to ensure that charities receive the appropriate amount of funding to enable
                      them to increase their impact in their community significantly. We continuously find ways to
                      combine our efforts with a growing network of resources to support NGOs in accomplishing more.
                      <br/>Become part of the FVIS family and watch how your contributions transform communities.
                    </p>
                  </div>
                </div>
              </article>
            </div>
          </div>
        </div>
      </div>
    </section>
    <Footer/>
  </div>
</template>

<script>
  import Header from '~/components/frontend/Header'
  import Footer from '~/components/frontend/Footer'

  export default {
    components: {
      Header, Footer
    },
    head() {
      return {
        title: 'Services - FvisNg'
      }
    },
    beforeMount() {
      this.$store.commit('frontmenu/RESET_MENU_TOGGLE')
    }
  }
</script>

<style>
</style>
