<template>
  <div>
    <Header />
    <div class="sub-header p-relative">
      <div class="overlay overlay-bg-black"></div>
      <div class="pattern"></div>
      <div class="section-padding">
        <div class="container">
          <div class="row">
            <div class="col-12">
              <div class="sub-header-content p-relative">
                <h1 class="text-custom-white lh-default fw-600">News</h1>
                <ul class="custom">
                  <li>
                    <NuxtLink to="/" class="text-custom-white">Home</NuxtLink>
                  </li>
                  <li class="text-custom-white active">News</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <section class="section-padding bg-gray our-articles">
      <div class="container">
        <div class="row">
          <article class="col-lg-4 col-md-6 post mb-xl-30" v-for="post in posts" :key="post.id">
            <div class="post-wrapper">
              <div class="blog-img animate-img">
                <NuxtLink :to="`/news/${post.slug}`">
                  <img :src="post.featured_img" class="full-width myimg" :alt="post.title" />
                </NuxtLink>
              </div>
              <div class="blog-meta padding-20">
                <div class="post-content mypost">
                  <h2>
                    <NuxtLink
                      :to="`/news/${post.slug}`"
                      class="text-custom-black fw-600"
                    >{{ post.title }}</NuxtLink>
                  </h2>
                </div>
                <div class="blog-links">
                  <NuxtLink :to="`/news/${post.slug}`" class="text-light-blue fs-14">Read More</NuxtLink>
                </div>
              </div>
            </div>
          </article>
          <span class="text-center">
            <infinite-loading spinner="spiral" @infinite="infiniteScroll"></infinite-loading>
          </span>
        </div>
      </div>
    </section>

    <Footer />
  </div>
</template>

<script>
import Header from '~/components/frontend/Header'
import Footer from '~/components/frontend/Footer'
export default {
  components: {
    Header,
    Footer
  },
  head() {
    return {
      title: 'News - Fvis Nig'
    }
  },
  beforeMount() {
    this.$store.commit('frontmenu/RESET_MENU_TOGGLE')
  },
  data() {
    return {
      posts: [],
      next_page: undefined
    }
  },
  filters: {
    strippedContent: function(string) {
      let regex = /(<([^>]+)>)/gi
      return string.replace(/(<([^>]+)>)/gi, '')
    }
  },
  async fetch() {
    const posts = await this.$axios.$get(
      `https://resource.fvisng.com/api/getposts/18`
    )
    this.posts = posts.data.data
    this.next_page = posts.data.next_page_url
  },
  methods: {
    async infiniteScroll($state) {
      if (this.next_page !== null) {
        const check = await this.$axios.$get(this.next_page)
        check.data.data.forEach(item => this.posts.push(item))
        $state.loaded()
        this.nextpage = check.data.next_page_url
      } else {
        $state.complete()
      }
    }
  }
}
</script>
<style scoped>
.myimg {
  object-fit: cover !important;
  height: 200px;
  min-height: 200px;
}
.mypost {
  min-height: 200px;
}
</style>