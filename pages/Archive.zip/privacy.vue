<template>
  <div>
    <Header />
    <div class="sub-header p-relative">
      <div class="overlay overlay-bg-black"></div>
      <div class="pattern"></div>
      <div class="section-padding">
        <div class="container">
          <div class="row">
            <div class="col-12">
              <div class="sub-header-content p-relative">
                <h1 class="text-custom-white lh-default fw-600">Privacy and Membership Policy</h1>
                <ul class="custom">
                  <li>
                    <NuxtLink to="/" class="text-custom-white">Home</NuxtLink>
                  </li>
                  <li class="text-custom-white active">Privacy and Membership Policy</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <section class="section-padding bg-gray our-articles">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="blog-detail padding-20">
              <div class="post-wrapper">
                <div class="blog-meta">
                  <h2>
                    <a class="text-dark fw-600">Privacy and Membership Policy</a>
                  </h2>
                  <h4 class="text-dark">1. Introduction</h4>
                  <p
                    class="text-light-white"
                  >Protecting your private information is our priority. This Statement of Privacy applies to www.fvis- llc.us and FIRST VIBRANT INTEGRATED SERVICES and governs data collection and usage. For the purposes of this Privacy Policy, unless otherwise noted, all references to FIRST VIBRANT INTEGRATED SERVICES include www.fvis- llc.us, FVIS, FVI SERVICES SDN BHD, www.fvis.com.my and www.fvis-llc.us. The FVIS website is an Ecommerce site. By using the FVIS website, you consent to the data practices described in this statement.</p>
                  <h4 class="text-dark">2. FVIS 0 Risk Privacy Program</h4>
                  <p
                    class="text-light-white"
                  >FVIS is a licensee of the FVIS 0 Risk Privacy Program. FVIS 0 Risk is an independent organization whose mission is to build users' trust and confidence in the Internet by promoting the use of fair information practices. Because we want to demonstrate our commitment to your privacy, we have agreed to disclose our information practices and have our privacy practices reviewed for compliance by FVIS 0 Risk.</p>
                  <p
                    class="text-light-white"
                  >If you have questions or concerns regarding this policy, you should first contact us at fvis.my@fvis.com.my. If you do not receive acknowledgement of your inquiry or your inquiry has not been satisfactorily addressed, you should contact FVIS 0 Risk at “fvis0risk@fvis-llc.us”. FVIS 0 Risk may serve as a liaison with us to resolve your concerns.</p>
                  <h4 class="text-dark">3. Membership Registration, Ranking, Investment, Premium and Refund Policy</h4>
                  <p class="text-light-white">Membership enrolment and registration fee of RM5,854.00 is not refundable.</p>
                  <ul>
                    <li>
                      b) Membership upgrade to any of the categories (Bronze, Silver, Gold, Diamond and Platinum membership) is refundable with 5 Business Days cooling off period with, 5% cancelation charges.</li>
                      <li>c) Investment is revocable within the agreeable cooling off period, with 5%
                      cancelation fee.</li>
                      <li>d) Premium services retainer is not refundable after signing of the premium contract.</li>
                      <li>e) Membershipfee/upgradearenotrefundableshouldservicesareprocessedand delivered within the agreeable time frame.</li>
                  </ul>
                  <h4 class="text-dark">4. Collection of Your Personal Information</h4>
                  <p class="text-light-white">
                    FVIS may collect personally identifiable information, such as your:</p>
<ul>
  <li>Name</li>
<li>Address</li>
<li>c) E-mailAddress</li>
<li>Phone Number</li>
    (this list is not exhaustive)
</ul>
If you purchase FVIS products and services, we collect billing and credit card information. This information is used to complete the purchase transaction. FVIS may also collect anonymous demographic information, which is not unique to you, such as your:
a) Age
b) Gender
c) Race
d) Religion
e) Project documents ETC
f) Political Affiliation
g) Household Income
(this list is not exhaustive)




                  <p
                    class="text-light-white"
                  >Protecting your private information is our priority. This Statement of Privacy applies to www.fvis- llc.us and FIRST VIBRANT INTEGRATED SERVICES and governs data collection and usage. For the purposes of this Privacy Policy, unless otherwise noted, all references to FIRST VIBRANT INTEGRATED SERVICES include www.fvis- llc.us, FVIS, FVI SERVICES SDN BHD, www.fvis.com.my and www.fvis-llc.us. The FVIS website is an Ecommerce site. By using the FVIS website, you consent to the data practices described in this statement.</p>

                  <p class="text-light-white">
                    Each business requires access to a unique combination of high-yielding
                    fixed income investments to maintain a successful portfolio. FVIS INVESTMENT LTD provides access to
                    treasury bonds, agency, and government bonds, corporate bonds, municipal bonds, mortgage-backed
                    securities, and more!
                  </p>
                  <p class="text-light-white">
                    Fixed income plays an integral role in any investor’s portfolio, but it is imperative to entrust
                    only the top industry players with your hard-earned money.
                    Whether your goal is to preserve principal, save for the future, diversify your investments,
                    or receive dependable income, fixed-income investments are vital in realizing your portfolio’s
                    potential and reach your financial goals.</p>
                    <p class="text-light-white">FVIS INVESTMENT LTD appreciates that many clients are risk-averse, which is why we developed an investment opportunity that delivers predictable income while maintaining an acceptable level
                    of risk. We make this incredible opportunity possible by investing in reliable long term
                    opportunities that promise high yields and a fast return on investment.
                    We also understand that every client’s budget vastly differs from the next. Hence we offer a
                    range of fixed investment plans. But no matter your budget and preferred plan, all our clients
                    enjoy our diligent service, prompt payments, and excellent service from our dedicated and
                    professional investment team.</p><p class="text-light-white">
                    Our highly skilled consultants are experts in servicing client portfolios, and knowledgeable
                    about the intensive research and due diligence that’s imperative to a lucrative fixed investment
                    portfolio. Through streamlined processes, we ensure both the safety and the liquidity of each
                    investment to provide the most attractive returns possible.</p><p class="text-light-white">
                    FVIS INVESTMENT LTD is committed to providing every client with personalized service to
                    ensure we meet your particular financial needs. Our fixed-income investment strategies emphasize both
                    long-term growth as well as immediate returns by continually monitoring the direction interest
                    rates may be headed.
                    Our offering to our clients is a unique proposition with the perfect blend between industry
                    expertise and unrivalled customer service, which achieves exemplary results – every time
                  </p>
                  <p class="text-light-white">>
                    We may gather additional personal or non-personal information in the future. FVIS encourages you to review the privacy statements of websites you choose to link to from FVIS so that you can understand how those websites collect, use and share your information. FVIS is not responsible for the privacy statements or other content on websites outside of the FVIS website.
                  </p>
                  <h4 class="text-dark">5. Use of your Personal Information</h4>
                  <p class="text-light-white">
                    FVIS collects and uses your personal information to operate its website(s) and deliver the services you have requested.</p> 
                    <p class="text-light-white">
FVIS may also use your personally identifiable information to inform you of other products or services available from FVIS and its affiliates. FVIS may also contact you via surveys to conduct research about your opinion of current services or of potential new services that may be offered.
                  </p>
                  <p class="text-light-white">
                    FVIS does not sell, rent or lease its customer lists to third parties. FVIS may, from time to time, contact you on behalf of external business partners about a particular offering that may be of interest to you. In those cases, your unique personally identifiable information (e-mail, name, address, telephone number) is not transferred to the third party. FVIS may share data with trusted partners to help perform statistical analysis, send you email or postal mail, provide customer support, or arrange for deliveries.</p>
<p class="text-light-white">All such third parties are prohibited from using your personal information except to provide these services to FVIS, and they are required to maintain the confidentiality of your information. FVIS may keep track of the websites and pages our users visit within FVIS, in order to determine what FVIS services are the most popular. This data is used to deliver customized content and advertising within FVIS to customers whose behaviour indicates that they are interested in a particular subject area.</p>
<p class="text-light-white">FVIS will disclose your personal information, without notice, only if required to do so by law or in the good faith belief that such action is necessary to: (a) conform to the edicts of the law or comply with legal process served on FVIS or the site; (b) protect and defend the rights or property of FVIS; and, (c) act under exigent circumstances to protect the personal safety of users of FVIS, or the public.
                  </p>
                    <h4 class="text-dark">6. Automatically Collected Information</h4>
                    <p class="text-light-white">
Information about your computer hardware and software may be automatically collected by FVIS. This information can include: your IP address, browser type, domain names, access times and referring website addresses. This information is used for the operation of the service, to maintain quality of the service, and to provide general statistics regarding use of the FVIS website.</p>
<h4 class="text-dark">7. Use of Cookies</h4>
<p class="text-light-white">
The FVIS website may use "cookies" to help you personalize your online experience. A cookie is a text file that is placed on your hard disk by a web page server. Cookies cannot be used to run programs or deliver viruses to your computer. Cookies are uniquely assigned to you, and can only be read by a web server in the domain that issued the cookie to you.</p>
<p class="text-light-white">One of the primary purposes of cookies is to provide a convenience feature to save you time. The purpose of a cookie is to tell the Web server that you have returned to a specific page. For example, if you personalize FVI SERVICES (M) SDN BHD pages, or register with FVI SERVICES (M) SDN BHD site or services, a cookie helps FVI SERVICES (M) SDN BHD to recall your specific information on subsequent visits. This simplifies the process of recording your personal information, such as billing addresses, shipping addresses, and so on. When you return to the same FVI SERVICES (M) SDN BHD website, the information you previously provided can be retrieved, so you can easily use the FVI SERVICES (M) SDN BHD features that you customized.</p>
<p class="text-light-white">
You have the ability to accept or decline cookies. Most Web browsers automatically accept cookies, but you can usually modify your browser setting to decline cookies if you prefer. If you choose to decline cookies, you may not be able to fully experience the interactive features of the FVI SERVICES (M) SDN BHD services or websites you visit.
                  </p>
                  
                    <h4 class="text-dark">8. Security of your Personal Information</h4>
                    <p class="text-light-white">
FVI SERVICES (M) SDN BHD secures your personal information from unauthorized access, use, or disclosure. FVI SERVICES (M) SDN BHD uses the following methods for this purpose: When personal information (such as a credit card number) is transmitted to other websites, it is protected through the use of encryption, such as the Secure Sockets Layer (SSL) protocol.</p>
<h4 class="text-dark">9. Children Under Thirteen</h4>
<p class="text-light-white">FVI SERVICES (M) SDN BHD does not knowingly collect personally identifiable information from children under the age of thirteen. If you are under the age of thirteen, you must ask your parent or guardian for permission to use this website.</p>
<h4 class="text-dark">10.Opt-Out &amp; Unsubscribe</h4>
<p class="text-light-white">We respect your privacy and give you an opportunity to opt-out of receiving announcements of certain information. Users may opt-out of receiving any or all communications from FVI SERVICES (M) SDN BHD by contacting us here:</p>
<p class="text-light-white">- Web page:
- Email: - Phone:</p>
<h4 class="text-dark">11.Changes to this Statement</h4>
<p class="text-light-white">FVI SERVICES (M) SDN BHD will occasionally update this Statement of Privacy to reflect company and customer feedback. FVI SERVICES (M) SDN BHD encourages you to periodically review this Statement to be informed of how FVI SERVICES (M) SDN BHD is protecting your information.</p>
<h4 class="text-dark">12.Contact Information</h4>
<p class="text-light-white">FVI SERVICES (M) SDN BHD welcomes your questions or comments regarding this Statement of Privacy. If you believe that FVI SERVICES (M) SDN BHD has not adhered to this Statement, please contact FVI SERVICES (M) SDN BHD at Level 36, Menara Citibank, 165, Jalan Ampang, 50450 Kuala Lumpur at this phone
+60321696163 and facsimile +60321696163
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <Footer />
  </div>
</template>

<script>
import Header from '~/components/frontend/Header'
import Footer from '~/components/frontend/Footer'
export default {
  components: {
    Header,
    Footer
  }
}
</script>

<style>
</style>