<template>
  <div>
    <Breadcrumb>
      <template v-slot:pagetitle>Loan History</template>
      <template v-slot:breadlinks>
        <ol class="breadcrumb mb-0 bg-transparent redial-light">
          <li class="breadcrumb-item">
            <NuxtLink to="/user/dashboard" class="redial-light">Home</NuxtLink>
          </li>
          <li class="breadcrumb-item active">Loan History</li>
        </ol>
      </template>
    </Breadcrumb>
    <div class="wrapper">
      <Nav />
      <div id="content">
        <div class="row">
          <div class="col-sm-12"></div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Header from '~/components/userdash/Header'
import Nav from '~/components/userdash/Nav'
import Breadcrumb from '~/components/userdash/Breadcrumb'
export default {
  layout: 'userdashboard',
  middleware: 'user',
  components: {
    Header,
    Nav,
    Breadcrumb
  },
  beforeMount() {
    this.$store.commit('navigationmenu/RESET_MENU_TOGGLE')
  }
}
</script>

<style>
</style>